// Placeholder Firebase config
const firebaseConfig = {
  apiKey: "fake-key",
  authDomain: "fake.firebaseapp.com",
  projectId: "fake-id"
};
