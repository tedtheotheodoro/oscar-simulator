// Simple placeholder for future i18n expansion
