
const questions = [
  {
    title: {
      pt: "Escolha seu perfil",
      en: "Choose your profile"
    },
    options: [
      { pt: "Ator", en: "Actor" },
      { pt: "Diretor", en: "Director" },
      { pt: "Roteirista", en: "Screenwriter" }
    ]
  }
];
